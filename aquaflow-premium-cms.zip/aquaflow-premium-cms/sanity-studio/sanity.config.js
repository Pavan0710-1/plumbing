import { defineConfig } from 'sanity';
import { structureTool } from 'sanity/structure';
import { visionTool } from '@sanity/vision';
import { schemaTypes } from './schemaTypes/index.js';

export default defineConfig({
  name: 'aquaflow',
  title: 'AquaFlow Website Editor',
  projectId: 'REPLACE_WITH_YOUR_SANITY_PROJECT_ID',
  dataset: 'production',
  plugins: [structureTool(), visionTool()],
  schema: { types: schemaTypes }
});