import { defineType, defineField } from 'sanity';

export const siteSettings = defineType({
  name: 'siteSettings',
  title: 'Website content',
  type: 'document',
  fields: [
    defineField({ name: 'businessName', title: 'Business name', type: 'string', validation: r => r.required() }),
    defineField({ name: 'eyebrow', title: 'Small heading above homepage title', type: 'string' }),
    defineField({ name: 'headline', title: 'Homepage main heading', type: 'string', validation: r => r.required() }),
    defineField({ name: 'intro', title: 'Homepage introduction', type: 'text', rows: 3 }),
    defineField({ name: 'heroImage', title: 'Homepage hero image', type: 'image', options: { hotspot: true } }),
    defineField({ name: 'primaryCta', title: 'Main button text', type: 'string' }),
    defineField({ name: 'secondaryCta', title: 'Second button text', type: 'string' }),
    defineField({ name: 'serviceArea', title: 'Service area', type: 'string' }),
    defineField({ name: 'aboutTitle', title: 'About section heading', type: 'string' }),
    defineField({ name: 'aboutText', title: 'About section text', type: 'text', rows: 5 }),
    defineField({ name: 'aboutImage', title: 'About section image', type: 'image', options: { hotspot: true } }),
    defineField({ name: 'phone', title: 'Business phone number', type: 'string' }),
    defineField({ name: 'email', title: 'Business email', type: 'string' }),
    defineField({ name: 'licenceLabel', title: 'Licence label', type: 'string', description: 'Only use if applicable and verified.' }),
    defineField({ name: 'licenceNumber', title: 'Licence details', type: 'string', description: 'Enter verified details, or leave blank.' }),
    defineField({ name: 'footerNote', title: 'Footer description', type: 'string' })
  ],
  preview: { select: { title: 'businessName', subtitle: 'headline', media: 'heroImage' } }
});