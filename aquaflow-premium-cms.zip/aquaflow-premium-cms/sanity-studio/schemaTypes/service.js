import { defineType, defineField } from 'sanity';

export const service = defineType({
  name: 'service',
  title: 'Services',
  type: 'document',
  fields: [
    defineField({ name: 'title', title: 'Service name', type: 'string', validation: r => r.required() }),
    defineField({ name: 'description', title: 'Short description', type: 'text', rows: 3, validation: r => r.required() }),
    defineField({ name: 'order', title: 'Display order', type: 'number', initialValue: 10 }),
    defineField({ name: 'icon', title: 'Reference number (optional)', type: 'string' })
  ],
  preview: { select: { title: 'title', subtitle: 'description' } }
});