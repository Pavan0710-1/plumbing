import { siteSettings } from './siteSettings.js';
import { service } from './service.js';
import { faq } from './faq.js';

export const schemaTypes = [siteSettings, service, faq];