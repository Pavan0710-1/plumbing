import { createClient } from '@sanity/client';
import imageUrlBuilder from '@sanity/image-url';

const projectId = import.meta.env.VITE_SANITY_PROJECT_ID;
const dataset = import.meta.env.VITE_SANITY_DATASET || 'production';

export const sanityReady = Boolean(projectId && projectId !== 'your_project_id');

export const sanity = sanityReady
  ? createClient({
      projectId,
      dataset,
      apiVersion: '2026-03-01',
      useCdn: true
    })
  : null;

const builder = sanityReady ? imageUrlBuilder(sanity) : null;

export function imageUrl(source, width = 1200) {
  if (!source || !builder) return '';
  return builder.image(source).width(width).auto('format').url();
}

export async function getWebsiteContent() {
  if (!sanity) return null;

  const query = `{
    "settings": *[_type == "siteSettings"][0]{
      businessName, eyebrow, headline, intro, phone, email, serviceArea,
      heroImage, aboutTitle, aboutText, aboutImage, primaryCta, secondaryCta,
      licenceLabel, licenceNumber, footerNote
    },
    "services": *[_type == "service"] | order(order asc){
      _id, title, description, icon, order
    },
    "faqs": *[_type == "faq"] | order(order asc){
      _id, question, answer, order
    }
  }`;

  try {
    return await sanity.fetch(query);
  } catch (error) {
    console.error('Could not load Sanity content:', error);
    return null;
  }
}