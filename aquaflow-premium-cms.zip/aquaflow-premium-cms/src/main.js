import './style.css';
import { getWebsiteContent, imageUrl, sanityReady } from './sanity.js';

const fallback = {
  settings: {
    businessName: 'AquaFlow Plumbing',
    eyebrow: 'PLUMBING, WITHOUT THE RUNAROUND',
    headline: 'Good plumbing starts with doing things properly.',
    intro: 'Thoughtful plumbing solutions for homes and businesses across Western Sydney. Clear communication, careful work and no unnecessary fuss.',
    phone: '0400 000 000',
    email: 'hello@example.com.au',
    serviceArea: 'Western Sydney, NSW',
    heroImage: null,
    aboutTitle: 'A better experience from the first call.',
    aboutText: 'From the first conversation to the final check, the focus is on making the process straightforward. You get clear information, practical recommendations and work completed with care.',
    aboutImage: null,
    primaryCta: 'Request a quote',
    secondaryCta: 'Explore services',
    licenceLabel: 'Licence details',
    licenceNumber: 'Add verified licence details',
    footerNote: 'Locally focused plumbing services.'
  },
  services: [
    { _id:'1', title:'General plumbing', description:'Repairs, maintenance and everyday plumbing work handled with care.', icon:'01' },
    { _id:'2', title:'Hot water systems', description:'Advice, servicing and replacement options for your hot water needs.', icon:'02' },
    { _id:'3', title:'Blocked drains', description:'Practical help identifying and resolving drainage issues.', icon:'03' },
    { _id:'4', title:'Leak detection', description:'Find the source of water issues and understand the next steps.', icon:'04' },
    { _id:'5', title:'Bathroom plumbing', description:'Plumbing work for bathroom upgrades, fixtures and renovations.', icon:'05' },
    { _id:'6', title:'Commercial plumbing', description:'Plumbing maintenance and repair support for business premises.', icon:'06' }
  ],
  faqs: [
    { _id:'f1', question:'Which areas do you service?', answer:'Add your confirmed suburbs and service boundaries here before publishing.' },
    { _id:'f2', question:'How do I request a quote?', answer:'Call or email using the contact details on this page. You can describe the work and arrange the next step.' },
    { _id:'f3', question:'Do you work on residential and commercial properties?', answer:'Update this answer to reflect the services the business actually provides.' }
  ]
};

const esc = (value = '') => String(value).replace(/[&<>"']/g, char => ({
  '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;'
}[char]));

function photo(source, fallbackUrl, width = 1400) {
  return source ? imageUrl(source, width) : fallbackUrl;
}

function render(data) {
  const settings = { ...fallback.settings, ...(data?.settings || {}) };
  const services = data?.services?.length ? data.services : fallback.services;
  const faqs = data?.faqs?.length ? data.faqs : fallback.faqs;
  const hero = photo(settings.heroImage, 'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?auto=format&fit=crop&w=1800&q=85', 1800);
  const about = photo(settings.aboutImage, 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=1200&q=85', 1200);
  const tel = (settings.phone || '').replace(/[^\d+]/g, '');

  document.querySelector('#app').innerHTML = `
    <header class="header" id="top">
      <a class="brand" href="#top" aria-label="${esc(settings.businessName)} home">
        <span class="brand-symbol">A<span></span></span>
        <span class="brand-name">${esc(settings.businessName)}</span>
      </a>
      <nav class="nav" id="nav">
        <a href="#services">Services</a><a href="#about">About</a><a href="#faqs">FAQs</a>
        <a class="nav-contact" href="#contact">Get in touch <span>↗</span></a>
      </nav>
      <button class="menu-toggle" aria-label="Open menu" aria-expanded="false"><i></i><i></i></button>
    </header>

    <main>
      <section class="hero section-wrap">
        <div class="hero-copy">
          <p class="eyebrow"><span class="eyebrow-line"></span>${esc(settings.eyebrow)}</p>
          <h1>${esc(settings.headline)}</h1>
          <p class="hero-intro">${esc(settings.intro)}</p>
          <div class="hero-actions">
            <a class="button button-dark" href="#contact">${esc(settings.primaryCta)} <span>↗</span></a>
            <a class="text-link" href="#services">${esc(settings.secondaryCta)} <span>↓</span></a>
          </div>
          <div class="hero-meta"><span class="meta-dot"></span><span>Serving ${esc(settings.serviceArea)}</span></div>
        </div>
        <div class="hero-visual">
          <img class="hero-image" src="${esc(hero)}" alt="Professional plumbing work" fetchpriority="high">
          <div class="image-caption"><span>01 / 03</span><span>Reliable work. Clear communication.</span></div>
          <div class="hero-stamp"><span>LOCAL</span><strong>PLUMBING<br>EXPERTISE</strong><span class="stamp-arrow">↗</span></div>
        </div>
        <div class="hero-bottom"><span>RESIDENTIAL & COMMERCIAL</span><span>SCROLL TO DISCOVER ↓</span></div>
      </section>

      <section class="intro-band">
        <div class="section-wrap intro-band-inner">
          <p class="eyebrow light"><span class="eyebrow-line"></span> THE AQUAFLOW APPROACH</p>
          <p class="intro-statement">The details matter. <em>So does the experience.</em></p>
          <p class="intro-side">Straightforward service, considered solutions and workmanship that respects your home or workplace.</p>
        </div>
      </section>

      <section class="services section-wrap" id="services">
        <div class="section-heading">
          <div><p class="eyebrow"><span class="eyebrow-line"></span> WHAT WE DO</p><h2>Practical solutions.<br><em>Done with care.</em></h2></div>
          <p class="section-note">From everyday repairs to larger plumbing projects, explore the services available from our team.</p>
        </div>
        <div class="service-grid">
          ${services.map((service, index) => `
            <article class="service-card reveal">
              <div class="service-top"><span>${String(index + 1).padStart(2,'0')}</span><span class="service-arrow">↗</span></div>
              <h3>${esc(service.title)}</h3>
              <p>${esc(service.description)}</p>
              <a href="#contact" aria-label="Enquire about ${esc(service.title)}">Enquire about this service <span>→</span></a>
            </article>`).join('')}
        </div>
      </section>

      <section class="about-section" id="about">
        <div class="about-image-wrap"><img src="${esc(about)}" alt="Plumbing professional at work" loading="lazy"></div>
        <div class="about-copy">
          <p class="eyebrow light"><span class="eyebrow-line"></span> A MORE CONSIDERED SERVICE</p>
          <h2>${esc(settings.aboutTitle)}</h2>
          <p>${esc(settings.aboutText)}</p>
          <div class="about-detail"><span>01</span><div><strong>Clear from the start</strong><small>Understand the work and the next steps.</small></div></div>
          <div class="about-detail"><span>02</span><div><strong>Care in every detail</strong><small>A tidy, respectful approach to the job.</small></div></div>
          <a class="button button-light" href="#contact">Talk to the team <span>↗</span></a>
        </div>
      </section>

      <section class="process section-wrap">
        <div class="section-heading">
          <div><p class="eyebrow"><span class="eyebrow-line"></span> HOW IT WORKS</p><h2>Simple from<br><em>start to finish.</em></h2></div>
          <p class="section-note">A clear process helps you know what to expect at every stage.</p>
        </div>
        <div class="process-grid">
          <div class="process-item"><span>01</span><h3>Get in touch</h3><p>Tell us what is happening and where the work is needed.</p></div>
          <div class="process-item"><span>02</span><h3>Discuss the job</h3><p>We clarify the requirements and the most suitable next step.</p></div>
          <div class="process-item"><span>03</span><h3>Confirm the details</h3><p>Scope, timing and pricing are discussed before work proceeds.</p></div>
          <div class="process-item"><span>04</span><h3>Work completed</h3><p>The agreed work is carried out with care and attention.</p></div>
        </div>
      </section>

      <section class="quote-band">
        <div class="section-wrap quote-inner"><p class="eyebrow light"><span class="eyebrow-line"></span> HAVE A PROJECT IN MIND?</p><h2>Let's get the<br><em>right solution.</em></h2><a class="button button-light" href="#contact">Start a conversation <span>↗</span></a></div>
        <div class="quote-orbit">AF</div>
      </section>

      <section class="faq-section section-wrap" id="faqs">
        <div class="faq-heading"><p class="eyebrow"><span class="eyebrow-line"></span> GOOD TO KNOW</p><h2>Questions,<br><em>answered.</em></h2><p>Can't find what you're looking for? Get in touch and we'll point you in the right direction.</p></div>
        <div class="faq-list">
          ${faqs.map((faq, index) => `<details class="faq-item"><summary><span>${String(index+1).padStart(2,'0')}</span>${esc(faq.question)}<b>+</b></summary><p>${esc(faq.answer)}</p></details>`).join('')}
        </div>
      </section>

      <section class="contact-section" id="contact">
        <div class="section-wrap contact-grid">
          <div class="contact-copy"><p class="eyebrow light"><span class="eyebrow-line"></span> CONTACT AQUAFLOW</p><h2>Tell us what<br><em>you need.</em></h2><p>Share a few details and we'll get back to you about the next step.</p>
            <div class="contact-detail"><span>CALL</span><a href="tel:${esc(tel)}">${esc(settings.phone)}</a></div>
            <div class="contact-detail"><span>EMAIL</span><a href="mailto:${esc(settings.email)}">${esc(settings.email)}</a></div>
            <div class="contact-detail"><span>LOCATION</span><strong>${esc(settings.serviceArea)}</strong></div>
          </div>
          <form class="contact-form" id="contact-form">
            <label>Your name<input name="name" autocomplete="name" placeholder="Name" required></label>
            <label>Email address<input type="email" name="email" autocomplete="email" placeholder="you@example.com" required></label>
            <label>Phone number<input name="phone" autocomplete="tel" placeholder="Your phone number"></label>
            <label>How can we help?<textarea name="message" rows="4" placeholder="Tell us a little about the work..." required></textarea></label>
            <button class="button button-light form-submit" type="submit">Prepare enquiry <span>↗</span></button>
            <p class="form-note">This form opens your email app to send the enquiry. Connect a form service before using this for live customer enquiries.</p>
            <p class="form-status" aria-live="polite"></p>
          </form>
        </div>
      </section>
    </main>

    <footer class="footer">
      <div class="section-wrap footer-main"><a class="brand footer-brand" href="#top"><span class="brand-symbol">A<span></span></span><span class="brand-name">${esc(settings.businessName)}</span></a><p>${esc(settings.footerNote)}</p><a href="#top" class="back-top">BACK TO TOP ↑</a></div>
      <div class="section-wrap footer-bottom"><span>© ${new Date().getFullYear()} ${esc(settings.businessName)}. All rights reserved.</span><span>${esc(settings.licenceLabel)}: ${esc(settings.licenceNumber)}</span><span>Website by VYRA</span></div>
    </footer>
    <a class="mobile-call" href="tel:${esc(tel)}">Call ${esc(settings.phone)} <span>↗</span></a>
  `;

  const header = document.querySelector('.header');
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('menu-open', open);
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open'); document.body.classList.remove('menu-open');
    toggle.setAttribute('aria-expanded', 'false');
  }));
  const onScroll = () => header.classList.toggle('scrolled', window.scrollY > 24);
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal, .process-item, .faq-item').forEach(el => observer.observe(el));

  document.querySelector('#contact-form').addEventListener('submit', event => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const subject = encodeURIComponent(`Website enquiry from ${form.get('name')}`);
    const body = encodeURIComponent(
      `Name: ${form.get('name')}\nEmail: ${form.get('email')}\nPhone: ${form.get('phone')}\n\nMessage:\n${form.get('message')}`
    );
    window.location.href = `mailto:${settings.email}?subject=${subject}&body=${body}`;
    document.querySelector('.form-status').textContent = 'Your email app should open with the enquiry ready to send.';
  });
}

async function start() {
  const content = await getWebsiteContent();
  render(content);
  if (!sanityReady) {
    console.info('Preview mode: add VITE_SANITY_PROJECT_ID to .env to connect the CMS.');
  }
}
start();
