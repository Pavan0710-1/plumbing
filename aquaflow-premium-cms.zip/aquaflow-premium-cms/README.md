# AquaFlow Plumbing — premium website + Sanity CMS

This project contains:
- `src/`: the customer-facing plumbing website (Vite + vanilla JavaScript).
- `sanity-studio/`: the separate Sanity editing dashboard and content models.

## 1. Create the Sanity project

1. Create a Sanity account at https://www.sanity.io/
2. Create a project and choose the dataset name `production`.
3. Copy the project ID from the project settings.
4. In the root folder, copy `.env.example` to `.env` and replace the placeholder:
   `VITE_SANITY_PROJECT_ID=your_real_project_id`
5. In `sanity-studio/sanity.config.js`, replace `REPLACE_WITH_YOUR_SANITY_PROJECT_ID` with the same project ID.

The public website reads published content from the `production` dataset. Do not put a Sanity write token or secret in the website `.env` file.

## 2. Run the website

From the repository root:

```bash
npm install
npm run dev
```

To make a production build:

```bash
npm run build
```

## 3. Run and deploy the CMS

Open a terminal in `sanity-studio`:

```bash
cd sanity-studio
npm install
npx sanity login
npm run dev
```

When the editor is ready, deploy the hosted dashboard:

```bash
npm run deploy
```

Sanity will provide a hosted Studio URL. Share that URL with the business owner after adding their account with the appropriate permissions. Do not share your own login.

## 4. Add the first content

In the Studio:
1. Open **Website content** and create one document. Fill in the business name, homepage heading, text, contact details and images.
2. Add **Services** documents. Set their display order to 1, 2, 3, etc.
3. Add **FAQs** documents and set their display order.
4. Publish each document. Published content is what the public website reads.

## 5. Deploy the website

Push the repository to GitHub and connect it to your hosting provider. Add `VITE_SANITY_PROJECT_ID` and `VITE_SANITY_DATASET=production` as environment variables in the hosting dashboard, then deploy.

## Important before a real client launch

- Replace all demo business details, phone number, email, service area and images.
- Only publish licence details, service claims, guarantees, reviews or emergency availability after the business verifies them.
- The enquiry form currently opens the visitor's email app. It does not store submissions or send them automatically. Connect a form service before relying on it for leads.
- The sample site uses remote Unsplash images as visual placeholders. Replace them with licensed client photography or properly licensed stock images.
- On Sanity's current Free plan, user roles are limited to Administrator and Viewer. A client editor-only role requires a plan that includes the Editor role. Avoid giving a client administrator access just to let them edit page content.
